/**
 * options.js — LearnPhish Settings
 * Fix #2:  Renamed LearnPhish
 * Fix #4:  Storage callbacks guarded with || {}
 * Fix #7:  appUrl saved and used
 * Fix #8:  Tips & Quiz settings wired
 */

var _chrome = (typeof chrome !== 'undefined') ? chrome : browser;

// ── Navigation ────────────────────────────────────────────────────────

function showPage(pageId, clickedNavItem) {
  document.querySelectorAll(".page").forEach(function(p) { p.classList.remove("active"); });
  document.querySelectorAll(".nav-item").forEach(function(n) { n.classList.remove("active"); });
  var page = document.getElementById("page-" + pageId);
  if (page) page.classList.add("active");
  if (clickedNavItem) clickedNavItem.classList.add("active");
  if (pageId === "whitelist") renderWhitelist();
}

// ── Load settings ─────────────────────────────────────────────────────

function loadSettings() {
  _chrome.storage.sync.get(
    { backendUrl: "http://localhost:8000", appUrl: "http://localhost:5173",
      threshold: 0.661, mode: "full", detectionEnabled: true,
      tipsEnabled: true, tipsIntervalMinutes: 30 },
    function(settings) {
      var s = settings || {};

      var backendEl = document.getElementById("backendUrl");
      if (backendEl) backendEl.value = s.backendUrl || "http://localhost:8000";

      var appEl = document.getElementById("appUrl");
      if (appEl) appEl.value = s.appUrl || "http://localhost:5173";

      var detectionEl = document.getElementById("detectionEnabled");
      if (detectionEl) detectionEl.checked = (s.detectionEnabled !== false);

      var modeEl = document.getElementById("mode");
      if (modeEl) modeEl.value = s.mode || "full";

      var sliderVal = Math.round((s.threshold || 0.661) * 100);
      var slider    = document.getElementById("thresholdSlider");
      if (slider) slider.value = sliderVal;

      var hiddenT = document.getElementById("threshold");
      if (hiddenT) hiddenT.value = (s.threshold || 0.661);

      var displayT = document.getElementById("thresholdDisplay");
      if (displayT) displayT.textContent = (s.threshold || 0.661).toFixed(3);

      selectModeUI(s.mode || "full");

      // Tips
      var tipsEl = document.getElementById("tipsEnabled");
      if (tipsEl) tipsEl.checked = (s.tipsEnabled !== false);

      var tipsSlider = document.getElementById("tipsSlider");
      if (tipsSlider) tipsSlider.value = s.tipsIntervalMinutes || 30;

      var tipsDisplay = document.getElementById("tipsDisplay");
      if (tipsDisplay) tipsDisplay.textContent = (s.tipsIntervalMinutes || 30) + " min";

      var tipsHidden = document.getElementById("tipsIntervalMinutes");
      if (tipsHidden) tipsHidden.value = s.tipsIntervalMinutes || 30;
    }
  );
}

// ── Save detection/connection settings ───────────────────────────────

function saveSettings() {
  var backendEl   = document.getElementById("backendUrl");
  var appEl       = document.getElementById("appUrl");
  var detectionEl = document.getElementById("detectionEnabled");
  var thresholdEl = document.getElementById("threshold");
  var modeEl      = document.getElementById("mode");

  var settings = {
    backendUrl:       (backendEl   ? backendEl.value.trim().replace(/\/$/, "")   : "http://localhost:8000"),
    appUrl:           (appEl       ? appEl.value.trim().replace(/\/$/, "")        : "http://localhost:5173"),
    detectionEnabled: (detectionEl ? detectionEl.checked                          : true),
    threshold:        parseFloat(thresholdEl ? thresholdEl.value : 0.661),
    mode:             (modeEl      ? modeEl.value                                 : "full"),
  };

  _chrome.storage.sync.set(settings, function() { showToast("Settings saved ✓"); });
}

// ── Save tips settings ────────────────────────────────────────────────

function saveTipsSettings() {
  var tipsEl      = document.getElementById("tipsEnabled");
  var tipsHidden  = document.getElementById("tipsIntervalMinutes");

  var settings = {
    tipsEnabled:          (tipsEl     ? tipsEl.checked                         : true),
    tipsIntervalMinutes:  parseInt(tipsHidden ? tipsHidden.value : 30, 10),
  };

  _chrome.storage.sync.set(settings, function() {
    showToast("Tips settings saved ✓");
    // Tell background to reschedule alarm
    _chrome.runtime.sendMessage({ type: "RESCHEDULE_TIPS" });
  });
}

// ── Mode selector ─────────────────────────────────────────────────────

function selectMode(mode) {
  var modeEl = document.getElementById("mode");
  if (modeEl) modeEl.value = mode;
  selectModeUI(mode);
}

function selectModeUI(mode) {
  var cardFull = document.getElementById("modeCardFull");
  var cardFast = document.getElementById("modeCardFast");
  if (cardFull) cardFull.classList.toggle("selected", mode === "full");
  if (cardFast) cardFast.classList.toggle("selected", mode === "fast");
}

// ── Threshold slider ──────────────────────────────────────────────────

function updateThresholdDisplay(rawVal) {
  var val = parseInt(rawVal, 10) / 100;
  var hiddenT = document.getElementById("threshold");
  if (hiddenT) hiddenT.value = val.toFixed(3);
  var displayT = document.getElementById("thresholdDisplay");
  if (displayT) displayT.textContent = val.toFixed(3);
}

// ── Tips interval slider ──────────────────────────────────────────────

function updateTipsDisplay(rawVal) {
  var val = parseInt(rawVal, 10);
  var hidden = document.getElementById("tipsIntervalMinutes");
  if (hidden) hidden.value = val;
  var display = document.getElementById("tipsDisplay");
  if (display) display.textContent = val + " min";
}

// ── Test connection ───────────────────────────────────────────────────

function testConnection() {
  var backendEl = document.getElementById("backendUrl");
  var backendUrl = backendEl ? backendEl.value.trim().replace(/\/$/, "") : "";
  var statusEl   = document.getElementById("connectionStatus");

  if (!statusEl) return;
  statusEl.style.color = "var(--text-dim)";
  statusEl.textContent = "⏳ Testing connection…";

  fetch(backendUrl + "/api/extension/predict", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: "https://google.com", mode: "fast", threshold: 0.661 }),
    signal: AbortSignal.timeout(5000),
  }).then(function(res) {
    if (res.ok) {
      statusEl.style.color = "var(--green)";
      statusEl.textContent = "✓ Connected — backend responded " + res.status;
    } else {
      statusEl.style.color = "var(--red)";
      statusEl.textContent = "✗ Backend error: HTTP " + res.status;
    }
  }).catch(function(err) {
    statusEl.style.color = "var(--red)";
    statusEl.textContent = "✗ Connection failed: " + err.message;
  });
}

// ── Whitelist ─────────────────────────────────────────────────────────

function renderWhitelist() {
  _chrome.storage.local.get({ whitelist: [] }, function(data) {
    var d = data || {};
    var whitelist = d.whitelist || [];
    var container = document.getElementById("whitelistContainer");
    if (!container) return;

    if (whitelist.length === 0) {
      container.innerHTML = '<div class="empty-state">No whitelisted domains yet.<br>Trust a site from the block page or add one below.</div>';
      return;
    }

    var rows = whitelist.map(function(domain) {
      return "<tr><td>" + escHtml(domain) + "</td>" +
        '<td style="text-align:right"><button class="remove-btn" data-domain="' + escHtml(domain) + '">Remove</button></td></tr>';
    }).join("");

    container.innerHTML =
      '<table class="wl-table"><thead><tr><th>Domain</th><th style="text-align:right">Action</th></tr></thead>' +
      "<tbody>" + rows + "</tbody></table>";

    container.querySelectorAll(".remove-btn").forEach(function(btn) {
      btn.addEventListener("click", function() { removeDomain(btn.getAttribute("data-domain")); });
    });
  });
}

function addDomain() {
  var input  = document.getElementById("newDomain");
  if (!input) return;
  var domain = input.value.trim().toLowerCase().replace(/^https?:\/\//i, "").split("/")[0];
  if (!domain) return;

  _chrome.storage.local.get({ whitelist: [] }, function(data) {
    var d = data || {};
    var list = d.whitelist || [];
    if (!list.includes(domain)) {
      list.push(domain);
      _chrome.storage.local.set({ whitelist: list }, function() {
        input.value = "";
        renderWhitelist();
        showToast(domain + " added ✓");
      });
    } else {
      showToast("Already in whitelist");
    }
  });
}

function removeDomain(domain) {
  _chrome.storage.local.get({ whitelist: [] }, function(data) {
    var d = data || {};
    var updated = (d.whitelist || []).filter(function(x) { return x !== domain; });
    _chrome.storage.local.set({ whitelist: updated }, function() {
      renderWhitelist();
      showToast(domain + " removed");
    });
  });
}

function clearWhitelist() {
  if (!confirm("Clear the entire local whitelist?")) return;
  _chrome.storage.local.set({ whitelist: [] }, function() {
    renderWhitelist();
    showToast("Whitelist cleared");
  });
}

// ── Toast ─────────────────────────────────────────────────────────────

var _toastTimer = null;
function showToast(msg) {
  var toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = "✓ " + msg;
  toast.classList.add("show");
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(function() { toast.classList.remove("show"); }, 2500);
}

function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ── Init ──────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", function() {
  loadSettings();

  // Sidebar nav
  document.querySelectorAll(".nav-item").forEach(function(navItem) {
    navItem.addEventListener("click", function() {
      var pageId = navItem.getAttribute("data-page");
      if (pageId) showPage(pageId, navItem);
    });
  });

  // Mode cards
  document.querySelectorAll(".mode-card").forEach(function(card) {
    card.addEventListener("click", function() {
      var mode = card.getAttribute("data-mode");
      if (mode) selectMode(mode);
    });
  });

  // Threshold slider
  var slider = document.getElementById("thresholdSlider");
  if (slider) slider.addEventListener("input", function() { updateThresholdDisplay(this.value); });

  // Tips slider
  var tipsSlider = document.getElementById("tipsSlider");
  if (tipsSlider) tipsSlider.addEventListener("input", function() { updateTipsDisplay(this.value); });

  // Save buttons
  var btnSaveDetection = document.getElementById("btnSaveDetection");
  if (btnSaveDetection) btnSaveDetection.addEventListener("click", saveSettings);

  var btnSaveConnection = document.getElementById("btnSaveConnection");
  if (btnSaveConnection) btnSaveConnection.addEventListener("click", saveSettings);

  var btnTestConnection = document.getElementById("btnTestConnection");
  if (btnTestConnection) btnTestConnection.addEventListener("click", testConnection);

  var btnSaveTips = document.getElementById("btnSaveTips");
  if (btnSaveTips) btnSaveTips.addEventListener("click", saveTipsSettings);

  // Whitelist
  var btnAddDomain = document.getElementById("btnAddDomain");
  if (btnAddDomain) btnAddDomain.addEventListener("click", addDomain);

  var newDomainInput = document.getElementById("newDomain");
  if (newDomainInput) newDomainInput.addEventListener("keydown", function(e) { if (e.key === "Enter") addDomain(); });

  var btnClearWhitelist = document.getElementById("btnClearWhitelist");
  if (btnClearWhitelist) btnClearWhitelist.addEventListener("click", clearWhitelist);
});
