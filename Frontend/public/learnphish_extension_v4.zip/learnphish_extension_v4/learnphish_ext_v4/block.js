/**
 * block.js — LearnPhish Block Page
 * Fix #6: originalUrl retrieved from storage.session first, URL param fallback
 * Fix #7: View Analysis opens /result?url=... on the app (direct result route)
 * Fix #2: Renamed LearnPhish throughout
 */

var _chrome = (typeof chrome !== 'undefined') ? chrome : browser;

var RULE_LABELS = {
  ip_address:        "Raw IP Address",
  punycode:          "Punycode Domain",
  suspicious_tld:    "Suspicious TLD",
  missing_https:     "No HTTPS",
  subdomain_padding: "Subdomain Padding",
  long_url:          "Excessive Length",
  phishing_keywords: "Phishing Keywords",
  at_symbol:         "@ Symbol in URL",
  double_slash:      "Double Slash",
  embedded_http:     "Embedded HTTP (Open Redirect)",
};

// ── Parse params and restore session data ─────────────────────────────

var params    = new URLSearchParams(window.location.search);
var tabId     = params.get("tabId") || "";
var originalUrl = "";
var report      = null;

function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// Fix #6: primary = session storage; fallback = URL param
function loadSessionData(callback) {
  if (!tabId) { callback(); return; }

  var key = "lp_block_" + tabId;

  // Ask background to retrieve from storage.session
  _chrome.runtime.sendMessage({ type: "GET_SESSION", key: key }, function(response) {
    var r = response || {};
    if (r.value && r.value.url) {
      originalUrl = r.value.url;
      report      = r.value.report || null;
    } else {
      // Fallback: URL params (legacy / Firefox)
      try {
        originalUrl = decodeURIComponent(params.get("url") || "");
        var raw = params.get("report");
        if (raw) report = JSON.parse(decodeURIComponent(raw));
      } catch (e) { console.warn("[LearnPhish] Param parse failed", e); }
    }
    callback();
  });
}

// ── Render helpers ────────────────────────────────────────────────────

function scoreColor(pct) {
  if (pct >= 0.85) return "#ff2d2d";
  if (pct >= 0.70) return "#ff6b35";
  if (pct >= 0.40) return "#f7c948";
  return "#10b981";
}

function setRiskBadgeClass(badge, level) {
  badge.className = "risk-level-badge";
  var l = (level || "").toLowerCase();
  badge.classList.add(["critical","high","medium","low"].includes(l) ? l : "low");
}

function animateRing(circle, pct) {
  var circumference = 226;
  var offset = circumference * (1 - Math.min(Math.max(pct, 0), 1));
  circle.style.stroke = scoreColor(pct);
  setTimeout(function() {
    circle.style.transition = "stroke-dashoffset 1s ease";
    circle.style.strokeDashoffset = String(offset);
  }, 200);
}

function severityClass(sev) {
  if (sev >= 3) return "sev-3";
  if (sev >= 2) return "sev-2";
  return "sev-1";
}

// ── Main render ───────────────────────────────────────────────────────

function render() {
  var urlEl = document.getElementById("blockedUrl");
  if (urlEl) urlEl.textContent = originalUrl || "(unknown URL)";

  if (!report) {
    var subEl = document.getElementById("skipReasonText");
    if (subEl) subEl.textContent = "No threat data available.";
    return;
  }

  var confidence = typeof report.confidence_score === "number" ? report.confidence_score : 0;
  var riskLevel  = report.risk_level || "high";
  var topReasons = Array.isArray(report.top_reasons) ? report.top_reasons : [];
  var skipReason = report.skip_reason || "";

  // Confidence ring
  var ringCircle = document.getElementById("ringCircle");
  var confVal    = document.getElementById("confidenceVal");
  if (ringCircle && confVal) {
    confVal.textContent = Math.round(confidence * 100) + "%";
    confVal.style.color = scoreColor(confidence);
    animateRing(ringCircle, confidence);
  }

  // Risk badge
  var badge = document.getElementById("riskBadge");
  if (badge) { badge.textContent = riskLevel.toUpperCase(); setRiskBadgeClass(badge, riskLevel); }

  // Sub-text — only show if there's an actual skip reason
  var skipEl = document.getElementById("skipReasonText");
  if (skipEl) {
    skipEl.textContent = skipReason || "";
    skipEl.style.display = skipReason ? "block" : "none";
  }

  // Footer
  var footerEl = document.getElementById("footerSkip");
  if (footerEl) footerEl.textContent = skipReason ? "Reason: " + skipReason : "";

  // Top reasons — always show at least one item (Fix #4)
  var reasonsList = document.getElementById("reasonsList");
  if (reasonsList) {
    var FALLBACK_REASONS = [
      "This site was flagged as suspicious by LearnPhish's detection engine.",
      "Make sure the website address is spelled correctly — phishers use typos to trick you.",
      "Verify there is no urgency language like 'Act NOW' or 'Your account will be closed'.",
      "Check that login or registration forms appear only on sites you intentionally visited.",
      "Ensure the site uses HTTPS (padlock icon) before entering any personal information.",
    ];

    var displayItems;
    if (topReasons.length > 0) {
      displayItems = topReasons;
    } else if (skipReason) {
      displayItems = [skipReason].concat(FALLBACK_REASONS.slice(0, 2));
    } else {
      displayItems = FALLBACK_REASONS;
    }

    reasonsList.innerHTML = displayItems.map(function(r) {
      return '<li class="reason-item"><span class="reason-icon">🔴</span><span>' + escHtml(r) + '</span></li>';
    }).join("");
  }

  // Heuristic chips
  var heuristic = report.heuristic;
  if (heuristic) {
    var chips = [];
    var allChecks = getattr(heuristic, "all_checks", []);
    allChecks.forEach(function(c) {
      if (c.triggered) chips.push({ label: RULE_LABELS[c.rule] || c.rule, sev: c.severity || 2 });
    });
    if (heuristic.brand_check && heuristic.brand_check.verdict !== "pass") {
      chips.push({ label: "Brand: " + (heuristic.brand_check.triggered_rule || "impersonation"), sev: 3 });
    }
    if (heuristic.dga_check && heuristic.dga_check.verdict !== "pass") {
      var dgaDets   = heuristic.dga_check.detections || [];
      var hardCount = dgaDets.filter(function(d) { return d.severity === "hard"; }).length;
      var softCount = dgaDets.filter(function(d) { return d.severity === "soft"; }).length;
      var parts = [];
      if (hardCount > 0) parts.push(hardCount + " hard");
      if (softCount > 0) parts.push(softCount + " soft");
      var dgaLabel = "DGA: " + (parts.length ? parts.join(" + ") + " indicator(s)" : heuristic.dga_check.verdict);
      chips.push({ label: dgaLabel, sev: heuristic.dga_check.verdict === "block" ? 3 : 2 });
    }
    if (chips.length > 0) {
      var titleEl = document.getElementById("heuristicTitle");
      if (titleEl) titleEl.style.display = "block";
      var chipsEl = document.getElementById("heuristicChips");
      if (chipsEl) {
        chipsEl.innerHTML = chips.map(function(c) {
          return '<span class="chip ' + severityClass(c.sev) + '">' + escHtml(c.label) + '</span>';
        }).join("");
      }
    }
  }
}

function getattr(obj, key, def) {
  return (obj && obj[key] !== undefined) ? obj[key] : def;
}

// ── Button actions ────────────────────────────────────────────────────

function goBack() {
  if (history.length > 1) history.back();
  else window.close();
}

// Fix #2 — register one-time bypass THEN navigate, so background won't re-block
function continueAnyway() {
  if (!originalUrl) {
    alert("Original URL not found. Close this tab and navigate manually.");
    return;
  }
  // Tell background to allow this hostname through exactly once
  _chrome.runtime.sendMessage({ type: "BYPASS_ONCE", url: originalUrl }, function() {
    window.location.href = originalUrl;
  });
}

function whitelistLocally() {
  if (!originalUrl) return;
  var hostname = "";
  try { hostname = new URL(originalUrl).hostname.toLowerCase(); } catch (e) { return; }

  var btn = document.getElementById("btnWhitelist");

  _chrome.storage.local.get({ whitelist: [] }, function(data) {
    var d = data || {};
    var list = d.whitelist || [];
    if (!list.includes(hostname)) {
      list.push(hostname);
      _chrome.storage.local.set({ whitelist: list });
    }
    if (btn) { btn.textContent = "✓ Whitelisted! Navigating…"; btn.disabled = true; }
    setTimeout(function() { window.location.href = originalUrl; }, 800);
  });
}

// Fix #7 — open the result page directly with URL as query param
// LearnPhish app domain is whitelisted in background.js so it's never blocked
function viewFullReport() {
  _chrome.storage.sync.get({ appUrl: "http://localhost:5173" }, function(s) {
    var settings = s || {};
    var appUrl   = (settings.appUrl || "http://localhost:5173").replace(/\/$/, "");
    // Pass URL directly to the result route — backend will re-run the scan
    // and display the full explainability report
    var target   = appUrl + "/result?url=" + encodeURIComponent(originalUrl);
    _chrome.tabs.create({ url: target });
  });
}

// ── Wire buttons after DOM ready ──────────────────────────────────────

document.addEventListener("DOMContentLoaded", function() {
  loadSessionData(function() {
    render();

    var btnBack = document.getElementById("btnBack");
    if (btnBack) btnBack.addEventListener("click", goBack);

    var btnWhitelist = document.getElementById("btnWhitelist");
    if (btnWhitelist) btnWhitelist.addEventListener("click", whitelistLocally);

    var btnFullReport = document.getElementById("btnFullReport");
    if (btnFullReport) btnFullReport.addEventListener("click", viewFullReport);

    var btnContinue = document.getElementById("btnContinue");
    if (btnContinue) btnContinue.addEventListener("click", continueAnyway);
  });
});
