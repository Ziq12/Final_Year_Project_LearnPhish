/**
 * popup.js — LearnPhish Toolbar Popup
 * Fix #2:  Renamed to LearnPhish
 * Fix #4:  All storage callbacks guarded with || {}
 * Fix #5:  browser/chrome compat shim for Firefox
 * Fix #9:  Blocked counter shown as circle badge
 */

// Fix #5 — cross-browser shim
var _chrome = (typeof chrome !== 'undefined') ? chrome : browser;

// ── Status UI ─────────────────────────────────────────────────────────

function updateStatusUI(enabled) {
  var pill = document.getElementById("statusPill");
  if (!pill) return;
  pill.textContent = enabled ? "Active" : "Paused";
  pill.className   = "status-pill " + (enabled ? "on" : "off");
}

// ── Blocked counter (Fix #9) ──────────────────────────────────────────

function updateBlockedCounter() {
  _chrome.runtime.sendMessage({ type: "GET_STATS" }, function(response) {
    if (_chrome.runtime.lastError) return; // popup closed
    var r = response || {};

    var totalEl = document.getElementById("blockedTotal");
    var todayEl = document.getElementById("blockedToday");
    if (totalEl) totalEl.textContent = r.blockedTotal || 0;
    if (todayEl) todayEl.textContent = r.blockedToday || 0;
  });
}

// ── Toggle ────────────────────────────────────────────────────────────

function toggleDetection() {
  var toggle  = document.getElementById("quickToggle");
  var enabled = toggle ? toggle.checked : true;
  _chrome.storage.sync.set({ detectionEnabled: enabled }, function() {
    updateStatusUI(enabled);
  });
}

// ── Manual scan (Fix #5) ──────────────────────────────────────────────

function scanManual() {
  var urlInput  = document.getElementById("manualUrl");
  var resultBox = document.getElementById("resultBox");
  var content   = document.getElementById("resultContent");
  if (!urlInput || !resultBox || !content) return;

  var url = urlInput.value.trim();
  if (!url) return;

  // Auto-prefix protocol if missing
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    url = "https://" + url;
    urlInput.value = url;
  }

  resultBox.classList.add("show");
  content.className   = "result-loading";
  content.textContent = "⏳ Scanning…";

  // Fix #5: sendMessage works in both Chrome and Firefox
  _chrome.runtime.sendMessage({ type: "SCAN_URL", url: url }, function(response) {
    if (_chrome.runtime.lastError) {
      content.className   = "result-phish";
      content.textContent = "✗ Error: " + _chrome.runtime.lastError.message;
      return;
    }

    var res = response || {};
    if (!res.ok) {
      content.className   = "result-phish";
      content.textContent = "✗ Scan failed: " + (res.error || "no response from background");
      return;
    }

    var r = res.result || {};

    // Fix #1: always show the dominant/relevant percentage.
    // confidence_score is the PHISHING probability (0-1).
    // If is_phishing → show phishing %. If safe → show safe (1 - score) %.
    var phishingPct = Math.round((r.confidence_score || 0) * 100);
    var safePct     = 100 - phishingPct;
    var riskLevel   = (r.risk_level || (r.is_phishing ? "high" : "low")).toUpperCase();

    if (r.is_phishing) {
      var topReason = (r.top_reasons && r.top_reasons[0]) ? escHtml(r.top_reasons[0]) : "";
      content.innerHTML =
        '<div class="result-row result-phish">' +
          '<span>🔴 PHISHING DETECTED</span>' +
          '<span class="val">' + phishingPct + '% phishing</span>' +
        '</div>' +
        '<div class="result-row">' +
          '<span style="color:var(--dim)">Risk Level</span>' +
          '<span class="val result-phish">' + riskLevel + '</span>' +
        '</div>' +
        (topReason
          ? '<div style="font-size:10px;color:var(--dim);margin-top:6px;line-height:1.5">' + topReason + '</div>'
          : "");
    } else {
      content.innerHTML =
        '<div class="result-row result-safe">' +
          '<span>✓ SAFE</span>' +
          '<span class="val">' + safePct + '% safe</span>' +
        '</div>' +
        '<div class="result-row">' +
          '<span style="color:var(--dim)">Risk Level</span>' +
          '<span class="val result-safe">' + riskLevel + '</span>' +
        '</div>';
    }
  });
}

// ── Navigation ────────────────────────────────────────────────────────

function openOptions() {
  _chrome.runtime.openOptionsPage();
}

function openApp() {
  // Fix #4: guard s with || {}
  _chrome.storage.sync.get({ appUrl: "http://localhost:5173" }, function(s) {
    var settings = s || {};
    var appUrl   = settings.appUrl || "http://localhost:5173";
    _chrome.tabs.create({ url: appUrl });
  });
}

// ── Utility ───────────────────────────────────────────────────────────

function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// ── Init ──────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", function() {

  // Fix #4: guard data with || {}
  _chrome.storage.sync.get({ detectionEnabled: true }, function(data) {
    var d = data || {};
    var toggle = document.getElementById("quickToggle");
    if (toggle) toggle.checked = (d.detectionEnabled !== false);
    updateStatusUI(d.detectionEnabled !== false);
  });

  // Blocked counter
  updateBlockedCounter();

  // Quick toggle
  var quickToggle = document.getElementById("quickToggle");
  if (quickToggle) quickToggle.addEventListener("change", toggleDetection);

  // Scan button
  var btnScan = document.getElementById("btnScan");
  if (btnScan) btnScan.addEventListener("click", scanManual);

  // Enter key in scan input
  var manualUrl = document.getElementById("manualUrl");
  if (manualUrl) manualUrl.addEventListener("keydown", function(e) {
    if (e.key === "Enter") scanManual();
  });

  // Settings
  var btnOpenOptions = document.getElementById("btnOpenOptions");
  if (btnOpenOptions) btnOpenOptions.addEventListener("click", openOptions);

  // Dashboard
  var btnOpenApp = document.getElementById("btnOpenApp");
  if (btnOpenApp) btnOpenApp.addEventListener("click", openApp);
});
