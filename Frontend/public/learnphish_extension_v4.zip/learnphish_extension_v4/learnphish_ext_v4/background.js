/**
 * background.js — LearnPhish Service Worker / Background Script
 * ─────────────────────────────────────────────────────────────
 * Fix #4: storage callbacks guarded with || {}
 * Fix #5: browser/chrome API compat layer
 * Fix #6: originalUrl stored in chrome.storage.session before redirect
 * Fix #7: LearnPhish domain whitelisted; view-analysis opens result route
 * Fix #8: chrome.alarms tips system
 * Fix #9: blockedCount incremented on every block
 */

// ── Cross-browser API shim (Fix #5) ──────────────────────────────────
var _chrome = (typeof chrome !== 'undefined') ? chrome : browser;

// ── Constants ─────────────────────────────────────────────────────────
var DEFAULT_BACKEND_URL = "http://localhost:8000";
var DEFAULT_APP_URL     = "http://localhost:5173";
var DEFAULT_THRESHOLD   = 0.661;
var DEFAULT_MODE        = "full";
var CACHE_TTL_MS        = 5 * 60 * 1000; // 5 minutes
var TIPS_ALARM_NAME     = "learnphish_tip";

// Domains NEVER scanned — always allowed through immediately
var ALWAYS_TRUSTED = [
  "localhost",
  "127.0.0.1",
];

var SKIP_PREFIXES = [
  "chrome://", "chrome-extension://", "edge://",
  "about:", "moz-extension://", "file://", "data:", "javascript:",
];

// ── In-memory scan cache ──────────────────────────────────────────────
var _cache      = {};
var _scanning   = {};   // tabId → true, prevents double-scan

// Fix #2: one-time bypass — hostnames allowed through exactly once
// Populated when user clicks "Continue anyway" on the block page.
var _bypassOnce = {}; // hostname → true

// ── Tips data (Fix #8) ───────────────────────────────────────────────
var TIPS = [
  { type: "tip",  text: "Always check the padlock 🔒 AND the domain name — HTTPS alone doesn't make a site safe." },
  { type: "tip",  text: "Phishing URLs often hide the real domain after an @ symbol: http://safe.com@evil.com/login" },
  { type: "tip",  text: "Legitimate banks never ask for your full password or PIN via email or popup." },
  { type: "tip",  text: "Hover over links before clicking — the status bar shows the real destination." },
  { type: "tip",  text: "Urgent language like 'Act NOW or lose access!' is a classic phishing pressure tactic. If a site creates a sense of emergency, slow down and verify manually." },
  { type: "tip",  text: "Punycode domains like xn--pypl-2ya.com look like 'paypl.com' in the address bar but are completely different sites." },
  { type: "tip",  text: "Subdomain tricks: paypal.com.evil.com — the real domain here is evil.com, not paypal.com. Always read the domain from right to left." },
  { type: "tip",  text: "Random-looking domains like xq7r2p.top are often DGA (machine-generated) phishing hosts used by botnets." },
  { type: "tip",  text: "Double file extensions like invoice.pdf.exe hide malware — always enable 'Show file extensions' in your operating system settings." },
  { type: "tip",  text: "Phishers often register typo domains: paypa1.com, goggle.com, arnazon.com. Always read the full address bar before logging in." },
  { type: "tip",  text: "Be suspicious of login or registration forms on sites you did not intentionally navigate to. Phishing sites often embed fake forms that look identical to real ones." },
  { type: "tip",  text: "A website with no HTTPS padlock should never receive your personal information, passwords, or payment details." },
  { type: "tip",  text: "Watch for urgency language in emails and on websites: 'Your account will be suspended', 'Claim your prize now', 'Immediate action required'. These are social-engineering triggers." },
  { type: "tip",  text: "Typos in a website's own content — misspelled words, broken grammar, inconsistent branding — are strong signals that the page is a phishing clone and not the real site." },
  { type: "tip",  text: "Before clicking any link in an email, go directly to the official website by typing the URL yourself. Never rely on links in unexpected emails, even if they look legitimate." },
  { type: "quiz", question: "Which of these URLs is most suspicious?",
    options: ["https://paypal.com/login", "https://paypal-secure-update.com/login", "https://www.paypal.com/account", "https://paypal.com/help"],
    answer: 1, explanation: "Brand names wrapped with hyphens (paypal-secure-update) are a classic prefix/suffix phishing pattern." },
  { type: "quiz", question: "What does a padlock icon in your browser guarantee?",
    options: ["The site is safe and legitimate", "Your connection is encrypted (HTTPS)", "The site has been verified by authorities", "No malware is present on the site"],
    answer: 1, explanation: "HTTPS only means the connection is encrypted — the site itself could still be a phishing page." },
  { type: "quiz", question: "What is a DGA domain?",
    options: ["A government-approved domain", "A machine-generated random domain used by botnets", "A domain with a digital certificate", "A domain registered more than 10 years ago"],
    answer: 1, explanation: "Domain Generation Algorithms produce random-looking hostnames like xq72rp.top to evade blocklists." },
  { type: "quiz", question: "Which TLD is most commonly abused for phishing?",
    options: [".com", ".gov", ".top", ".edu"],
    answer: 2, explanation: ".top, .xyz, .click and .loan are heavily abused because they are cheap and loosely regulated." },
  { type: "quiz", question: "You get an email saying 'Your account will be closed in 24 hours'. What should you do?",
    options: ["Click the link immediately", "Reply with your password to verify", "Go directly to the official site by typing the URL yourself", "Forward it to friends to warn them"],
    answer: 2, explanation: "Always navigate to the official site manually. Urgency is a social-engineering trigger used by phishers." },
  { type: "quiz", question: "A site has perfect design but the URL is 'secure-login-paypa1.com'. What is this?",
    options: ["A legitimate PayPal login page", "A typosquatting phishing site", "A PayPal test environment", "A regional PayPal subdomain"],
    answer: 1, explanation: "Replacing 'l' with '1' is a typosquatting technique. Always read every character of the domain carefully." },
];

// ── Helpers ───────────────────────────────────────────────────────────

function shouldSkip(url) {
  return SKIP_PREFIXES.some(function(p) { return url.startsWith(p); });
}

function extractHostname(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/:\d+$/, ""); }
  catch (e) { return ""; }
}

function isTrusted(hostname, whitelist, backendHostname, appHostname) {
  if (ALWAYS_TRUSTED.indexOf(hostname) !== -1) return true;
  if (hostname === backendHostname)             return true;
  if (hostname === appHostname)                 return true;
  return whitelist.some(function(entry) {
    return hostname === entry || hostname.endsWith("." + entry);
  });
}

function getCached(hostname) {
  var entry = _cache[hostname];
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_TTL_MS) { delete _cache[hostname]; return null; }
  return entry.result;
}

function setCache(hostname, result) {
  _cache[hostname] = { result: result, ts: Date.now() };
  // Keep under 500 entries
  var keys = Object.keys(_cache);
  if (keys.length > 500) delete _cache[keys[0]];
}

// Fix #9 — increment blocked counters
function incrementBlockedCount() {
  _chrome.storage.local.get({ blockedTotal: 0, blockedToday: 0, blockedDate: "" }, function(data) {
    var d = data || {};
    var today = new Date().toISOString().slice(0, 10);
    var newToday = (d.blockedDate === today) ? (d.blockedToday || 0) + 1 : 1;
    _chrome.storage.local.set({
      blockedTotal: (d.blockedTotal || 0) + 1,
      blockedToday: newToday,
      blockedDate:  today,
    });
  });
}

// ── API call ──────────────────────────────────────────────────────────

function scanUrl(url, settings) {
  var s = settings || {};
  var backendUrl = s.backendUrl || DEFAULT_BACKEND_URL;
  var threshold  = s.threshold  || DEFAULT_THRESHOLD;
  var mode       = s.mode       || DEFAULT_MODE;

  return fetch(backendUrl + "/api/extension/predict", {
    method:  "POST",
    headers: { 
      "Content-Type": "application/json",
      "x-api-key": "abcdefghijklmnopqrstuvwxyz123456"
    },
    body:    JSON.stringify({ url: url, threshold: threshold, mode: mode }),
    signal:  AbortSignal.timeout(8000),
  }).then(function(res) {
    if (!res.ok) throw new Error("API " + res.status);
    return res.json();
  });
}

// Fix #6 — store originalUrl in session storage keyed by tabId
function storeSessionUrl(tabId, url, report) {
  var key = "lp_block_" + tabId;
  var payload = { url: url, report: report };
  try {
    // MV3: chrome.storage.session; MV2/Firefox: fall back to local
    var store = (_chrome.storage.session) ? _chrome.storage.session : _chrome.storage.local;
    var obj = {};
    obj[key] = payload;
    store.set(obj);
  } catch(e) {
    // Last resort: just use local
    var obj2 = {};
    obj2[key] = payload;
    _chrome.storage.local.set(obj2);
  }
}

function redirectToBlockPage(tabId, originalUrl, report) {
  storeSessionUrl(tabId, originalUrl, report);
  incrementBlockedCount();
  // Pass tabId so block.js can retrieve full report from storage
  var blockUrl = _chrome.runtime.getURL("block.html") + "?tabId=" + tabId;
  _chrome.tabs.update(tabId, { url: blockUrl });
}

// ── Main interception ─────────────────────────────────────────────────

function handleNavigation(tabId, url) {
  if (!url || shouldSkip(url)) return;
  if (_scanning[tabId])        return;
  if (url.includes(_chrome.runtime.getURL("block.html"))) return;
  if (url.includes(_chrome.runtime.getURL("tip.html")))   return;

  _chrome.storage.sync.get(
    { backendUrl: DEFAULT_BACKEND_URL, threshold: DEFAULT_THRESHOLD,
      mode: DEFAULT_MODE, detectionEnabled: true,
      appUrl: DEFAULT_APP_URL },
    function(settings) {
      var s = settings || {};
      if (s.detectionEnabled === false) return;

      var hostname = extractHostname(url);
      if (!hostname) return;

      var backendHostname = extractHostname(s.backendUrl || DEFAULT_BACKEND_URL);
      var appHostname     = extractHostname(s.appUrl     || DEFAULT_APP_URL);

      _chrome.storage.local.get({ whitelist: [] }, function(localData) {
        var ld = localData || {};
        var whitelist = ld.whitelist || [];

        if (isTrusted(hostname, whitelist, backendHostname, appHostname)) return;

        // Fix #2: one-time bypass — skip scan and clear the token
        if (_bypassOnce[hostname]) {
          delete _bypassOnce[hostname];
          return;
        }

        // Check in-memory cache
        var cached = getCached(hostname);
        if (cached !== null) {
          if (cached.is_phishing) redirectToBlockPage(tabId, url, cached);
          return;
        }

        _scanning[tabId] = true;

        scanUrl(url, s).then(function(result) {
          setCache(hostname, result);
          if (result.is_phishing) redirectToBlockPage(tabId, url, result);
        }).catch(function(err) {
          console.warn("[LearnPhish] Scan failed:", err.message);
        }).then(function() {
          delete _scanning[tabId];
        });
      });
    }
  );
}

// ── Event listeners ───────────────────────────────────────────────────

if (_chrome.webNavigation && _chrome.webNavigation.onBeforeNavigate) {
  _chrome.webNavigation.onBeforeNavigate.addListener(
    function(details) {
      if (details.frameId !== 0) return;
      handleNavigation(details.tabId, details.url);
    },
    { url: [{ schemes: ["http", "https"] }] }
  );
}

_chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
  if (changeInfo.url) handleNavigation(tabId, changeInfo.url);
});

// ── Message handler ───────────────────────────────────────────────────

_chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (!msg || !msg.type) return false;

  if (msg.type === "SCAN_URL") {
    _chrome.storage.sync.get(
      { backendUrl: DEFAULT_BACKEND_URL, threshold: DEFAULT_THRESHOLD, mode: DEFAULT_MODE },
      function(settings) {
        var s = settings || {};
        scanUrl(msg.url, s)
          .then(function(result) { sendResponse({ ok: true, result: result }); })
          .catch(function(err)   { sendResponse({ ok: false, error: err.message }); });
      }
    );
    return true; // keep channel open
  }

  if (msg.type === "GET_SESSION") {
    var store = (_chrome.storage.session) ? _chrome.storage.session : _chrome.storage.local;
    store.get(msg.key, function(data) {
      var d = data || {};
      sendResponse({ value: d[msg.key] || null });
    });
    return true;
  }

  if (msg.type === "BYPASS_ONCE") {
    // Register a one-time pass for this hostname so "Continue anyway" works
    var h = "";
    try { h = new URL(msg.url).hostname.toLowerCase(); } catch(e) {}
    if (h) _bypassOnce[h] = true;
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "CLEAR_CACHE") {
    _cache = {};
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "RESCHEDULE_TIPS") {
    _chrome.alarms.clear(TIPS_ALARM_NAME, function() { scheduleTips(); });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "GET_STATS") {
    _chrome.storage.local.get(
      { blockedTotal: 0, blockedToday: 0, blockedDate: "" },
      function(data) {
        var d = data || {};
        var today = new Date().toISOString().slice(0, 10);
        sendResponse({
          blockedTotal: d.blockedTotal || 0,
          blockedToday: (d.blockedDate === today) ? (d.blockedToday || 0) : 0,
        });
      }
    );
    return true;
  }

  return false;
});

// ── Tips / Quiz alarm system (Fix #8) ────────────────────────────────

function scheduleTips() {
  _chrome.storage.sync.get(
    { tipsEnabled: true, tipsIntervalMinutes: 30 },
    function(settings) {
      var s = settings || {};
      if (!s.tipsEnabled) {
        _chrome.alarms.clear(TIPS_ALARM_NAME);
        return;
      }
      var intervalMinutes = Math.max(5, s.tipsIntervalMinutes || 30);
      _chrome.alarms.get(TIPS_ALARM_NAME, function(existing) {
        if (!existing) {
          _chrome.alarms.create(TIPS_ALARM_NAME, {
            delayInMinutes:    intervalMinutes,
            periodInMinutes:   intervalMinutes,
          });
        }
      });
    }
  );
}

_chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name !== TIPS_ALARM_NAME) return;

  _chrome.storage.sync.get({ tipsEnabled: true }, function(s) {
    var settings = s || {};
    if (settings.tipsEnabled === false) return;

    // Pick a random tip/quiz and store it for tip.html to read
    var item = TIPS[Math.floor(Math.random() * TIPS.length)];
    _chrome.storage.local.set({ currentTip: item }, function() {
      // Open tip.html as a small popup-style tab
      _chrome.tabs.create({
        url:    _chrome.runtime.getURL("tip.html"),
        active: false,
      });
    });
  });
});

// Init
scheduleTips();

console.log("[LearnPhish] Service worker started.");
