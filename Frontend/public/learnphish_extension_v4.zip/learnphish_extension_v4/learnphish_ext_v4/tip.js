/**
 * tip.js — LearnPhish Tip / Quiz Card
 * Fix #5: Bigger card, progress bar, richer quiz layout, responsive.
 */

var _chrome = (typeof chrome !== 'undefined') ? chrome : browser;
var _answered       = false;
var _countdownSec   = 15;
var _timerInterval  = null;
var _progressTimer  = null;

var OPTION_LETTERS  = ["A", "B", "C", "D"];

function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// ── Countdown + progress bar ──────────────────────────────────────────

function startCountdown(totalSec) {
  _countdownSec = totalSec;
  var countdownEl  = document.getElementById("countdown");
  var progressBar  = document.getElementById("progressBar");

  // Kick off progress bar drain
  // Start at 100% width, shrink to 0 over totalSec seconds
  if (progressBar) {
    progressBar.style.width = "100%";
    // Use a small delay so the CSS transition picks up the initial value
    setTimeout(function() {
      progressBar.style.transitionDuration = totalSec + "s";
      progressBar.style.width = "0%";
    }, 50);
  }

  _timerInterval = setInterval(function() {
    _countdownSec -= 1;
    if (countdownEl) countdownEl.textContent = _countdownSec;
    if (_countdownSec <= 0) {
      clearInterval(_timerInterval);
      window.close();
    }
  }, 1000);
}

function stopCountdown() {
  clearInterval(_timerInterval);
  var progressBar = document.getElementById("progressBar");
  if (progressBar) {
    // Freeze the bar at current position
    var computed = window.getComputedStyle(progressBar).width;
    progressBar.style.transition = "none";
    progressBar.style.width = computed;
  }
  var autoCloseText = document.getElementById("autoCloseText");
  if (autoCloseText) autoCloseText.style.display = "none";
}

// ── Render tip ────────────────────────────────────────────────────────

function renderTip(item) {
  var content = document.getElementById("content");
  if (content) {
    content.innerHTML = '<div class="tip-text">' + escHtml(item.text) + '</div>';
  }

  // Show "Got it" button immediately for tips
  var btnGotIt = document.getElementById("btnGotIt");
  if (btnGotIt) btnGotIt.classList.add("show");

  startCountdown(15);
}

// ── Render quiz ───────────────────────────────────────────────────────

function renderQuiz(item) {
  // Update header
  var cardIcon      = document.getElementById("cardIcon");
  var cardType      = document.getElementById("cardType");
  var cardTitleText = document.getElementById("cardTitleText");

  if (cardIcon)      { cardIcon.textContent = "🧩"; cardIcon.className = "card-icon quiz"; }
  if (cardType)      { cardType.textContent = "Quick Quiz"; cardType.className = "card-type quiz"; }
  if (cardTitleText) { cardTitleText.textContent = "Test Your Knowledge"; }

  // Build options
  var optionsHtml = item.options.map(function(opt, idx) {
    return '<button class="quiz-option" id="opt-' + idx + '" data-idx="' + idx + '" data-letter="' + OPTION_LETTERS[idx] + '">'
      + escHtml(opt)
      + '</button>';
  }).join("");

  var content = document.getElementById("content");
  if (content) {
    content.innerHTML =
      '<div class="quiz-question">' + escHtml(item.question) + '</div>' +
      '<div class="quiz-options" id="quizOptions">' + optionsHtml + '</div>';

    // Wire option clicks
    content.querySelectorAll(".quiz-option").forEach(function(btn) {
      btn.addEventListener("click", function() {
        if (_answered) return;
        _answered = true;

        var chosen  = parseInt(btn.getAttribute("data-idx"), 10);
        var correct = item.answer;

        // Mark all options
        content.querySelectorAll(".quiz-option").forEach(function(b) {
          b.disabled = true;
          var i = parseInt(b.getAttribute("data-idx"), 10);
          if (i === correct)                    b.classList.add("correct");
          else if (i === chosen && chosen !== correct) b.classList.add("wrong");
        });

        // Show explanation
        var explanation     = document.getElementById("explanation");
        var resultLabel     = document.getElementById("resultLabel");
        var explanationText = document.getElementById("explanationText");

        if (explanation && resultLabel && explanationText) {
          var isCorrect = chosen === correct;
          resultLabel.textContent  = isCorrect ? "✓ Correct!" : "✗ Not quite.";
          resultLabel.className    = "result-label " + (isCorrect ? "correct-label" : "wrong-label");
          explanationText.textContent = " " + (item.explanation || "");
          explanation.classList.add("show");
        }

        // Show "Got it" and stop the countdown
        var btnGotIt = document.getElementById("btnGotIt");
        if (btnGotIt) btnGotIt.classList.add("show");
        stopCountdown();

        // Restart a fresh 20s countdown after answering so user can read
        startCountdown(20);
      });
    });
  }

  // Quizzes get 60s to answer before auto-close
  var autoCloseText = document.getElementById("autoCloseText");
  if (autoCloseText) {
    autoCloseText.innerHTML = 'Answer to continue &nbsp;<span class="countdown" id="countdown">60</span>s';
  }
  startCountdown(60);
}

// ── Close ─────────────────────────────────────────────────────────────

function closeTip() {
  clearInterval(_timerInterval);
  window.close();
}

// ── Init ──────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", function() {
  // Wire close buttons
  var btnX = document.getElementById("btnX");
  if (btnX) btnX.addEventListener("click", closeTip);

  var btnGotIt = document.getElementById("btnGotIt");
  if (btnGotIt) btnGotIt.addEventListener("click", closeTip);

  // Load tip from storage
  _chrome.storage.local.get({ currentTip: null }, function(data) {
    var d    = data || {};
    var item = d.currentTip;

    // Fallback if nothing is stored yet
    if (!item) {
      item = {
        type: "tip",
        text: "Always verify the domain name before entering any personal information. Phishers rely on users not reading the address bar carefully."
      };
    }

    if (item.type === "quiz") {
      renderQuiz(item);
    } else {
      renderTip(item);
    }
  });
});
