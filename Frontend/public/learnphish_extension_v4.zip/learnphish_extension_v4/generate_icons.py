#!/usr/bin/env python3
"""
generate_icons.py — run once to produce the PNG icons the extension needs.
Requires: pip install Pillow

Usage: python generate_icons.py
Output: icons/icon16.png, icons/icon48.png, icons/icon128.png
"""
import os

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Pillow not found. Install with: pip install Pillow")
    print("Then re-run this script to generate PNG icons.")
    print()
    print("Alternatively, use any shield icon as icons/icon16.png,")
    print("icons/icon48.png, and icons/icon128.png.")
    exit(0)

os.makedirs("icons", exist_ok=True)

SIZES = [16, 48, 128]

for size in SIZES:
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Background circle — dark navy
    pad  = size * 0.06
    draw.ellipse([pad, pad, size-pad, size-pad], fill=(13, 13, 30, 255))

    # Shield shape (simplified as rounded rect)
    sp   = size * 0.18
    draw.rounded_rectangle(
        [sp, sp, size-sp, size-sp],
        radius=size * 0.15,
        fill=(79, 142, 247, 255),
    )

    # Inner shield (white)
    sp2 = size * 0.28
    draw.rounded_rectangle(
        [sp2, sp2, size-sp2, size-sp2],
        radius=size * 0.1,
        fill=(255, 255, 255, 200),
    )

    # Checkmark or "PG" text for larger sizes
    if size >= 48:
        cx, cy = size // 2, size // 2
        lw = max(2, size // 20)
        # Simple checkmark
        pts = [
            (cx - size*0.15, cy),
            (cx - size*0.04, cy + size*0.12),
            (cx + size*0.18, cy - size*0.12),
        ]
        draw.line(pts, fill=(13, 13, 30, 255), width=lw)

    img.save(f"icons/icon{size}.png")
    print(f"Generated icons/icon{size}.png")

print("\nAll icons generated. Place the icons/ folder inside dev/browser_extension/")
