# PhishGuard Browser Extension

Real-time phishing detection for Chrome, Edge, and Firefox — powered by the PhishGuard v5 backend.

---

## File Structure

```
browser_extension/
├── manifest.json                  MV3 extension manifest
├── background.js                  Service worker: URL interception + API calls
├── block.html / block.js          Educational threat intervention page
├── options.html / options.js      Settings panel (detection mode, threshold, whitelist)
├── popup.html / popup.js          Toolbar popup (status + manual scan)
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── generate_icons.py              Helper to regenerate icons (requires Pillow)
└── backend_extension_endpoint.py  Code to add to main.py (read the header comments)
```

---

## Backend Setup (Required First)

### 1. Add the extension endpoint to `main.py`

Open `backend_extension_endpoint.py` and follow the 3-step instructions in its header docstring:

1. Add `slowapi` + `CORSMiddleware` imports
2. Initialize the rate limiter and CORS middleware after `app = FastAPI(...)`
3. Paste the `ExtensionRequest` model and `extension_predict()` endpoint before `app.mount()`

### 2. Verify `slowapi` is installed

```bash
pip install slowapi
```
It's already in `requirements.txt`.

### 3. Test the endpoint

```bash
# Should return JSON with is_phishing, confidence_score, etc.
curl -X POST http://localhost:8000/api/extension/predict \
  -H "Content-Type: application/json" \
  -d '{"url": "https://secure-paypal-update.com/login", "mode": "full"}'

# Rate limit test — send 6 requests quickly
for i in {1..6}; do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST http://localhost:8000/api/extension/predict \
    -H "Content-Type: application/json" \
    -d '{"url":"https://google.com"}'
done
# The 6th should return 429
```

---

## Extension Installation

### Chrome / Edge

1. Open `chrome://extensions/` (or `edge://extensions/`)
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked** → select this `browser_extension/` folder
4. The PhishGuard icon appears in the toolbar

### Firefox

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select `manifest.json` inside this folder

---

## Configuration

Click the PhishGuard toolbar icon → **Settings** (or right-click → Options).

| Setting | Default | Description |
|---------|---------|-------------|
| Backend URL | `http://localhost:8000` | Your PhishGuard v5 instance |
| Detection Mode | Full | Full 4-stage pipeline vs ML-only fast mode |
| ML Threshold | 0.661 | Phishing probability cutoff (0.10–1.00) |
| Real-Time Detection | Enabled | Toggle automatic URL scanning |

---

## How It Works

```
User navigates → webNavigation.onBeforeNavigate fires
  → Check local whitelist (chrome.storage.local)
  → If not whitelisted: POST /api/extension/predict
      → Backend: WL/BL check → Heuristics → ML (if needed)
      → Returns: {is_phishing, confidence_score, top_reasons, ...}
  → is_phishing = true → redirect to block.html?report=...
  → Block page: displays risk level, top reasons, domain breakdown
      → "Go Back"         → history.back()
      → "Whitelist"       → saves hostname to chrome.storage.local
      → "Continue Anyway" → navigates to original URL
      → "Full Analysis"   → opens PhishGuard dashboard
```

---

## Security Model

- **No API tokens** — the extension uses CORS origin restrictions + IP-based rate limiting (5 req/s per IP via slowapi)
- **No data stored remotely** — whitelist and settings live in `chrome.storage.sync` / `chrome.storage.local`
- **Fail open** — if the backend is unreachable (network error, timeout), the extension allows navigation rather than blocking everything
- **Cache** — scan results are cached in-memory for 5 minutes per hostname to reduce API calls

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Extension not triggering | Check `host_permissions` in `manifest.json` matches your backend domain |
| CORS errors in console | Ensure backend has CORSMiddleware with `chrome-extension://*` |
| 429 Too Many Requests | You're scanning very fast; the rate limit is 5 req/s per IP |
| Block page not rendering data | Check that `report` URL param is valid JSON; reload the extension |
| High latency | Switch to `Fast` mode in settings |
| False positives persist | Remove the hostname from the whitelist in Options → Whitelist |
